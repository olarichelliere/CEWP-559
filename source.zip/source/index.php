<?php

phpinfo();
