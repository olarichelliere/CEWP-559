<?php


require_once __DIR__.'/models/about_model.php';
require_once __DIR__.'/views/about_view.php';
require_once __DIR__.'/controllers/about_controller.php';

require_once __DIR__.'/models/index_model.php';
require_once __DIR__.'/views/index_view.php';
require_once __DIR__.'/controllers/index_controller.php';
