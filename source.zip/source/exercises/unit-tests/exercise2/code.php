<?php

class Email {

    protected $email;

    public function __construct($email) {
        $this->email = $email;
    }

    public function isValid() {
        //...
    }
}
