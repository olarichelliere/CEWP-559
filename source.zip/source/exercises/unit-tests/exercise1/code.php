<?php

class Calculator
{
    public static function sum(float $x, float $y): float
    {
        return $x + $y;
    }

    public static function multiply(float $x, float $y): float
    {
        return $x * $y;
    }
}
