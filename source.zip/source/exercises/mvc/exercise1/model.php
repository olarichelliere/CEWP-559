<?php

class Model
{
    public $string;

    public function __construct(){
        $this->string = 'PHP/MySQL @ Concordia, Click Here';
    }
}