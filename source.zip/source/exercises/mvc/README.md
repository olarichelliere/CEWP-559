# MVC #

## Exercise - 1 ##

- Add a click handler for the Controller. A function called `clicked` which modifies the Model's string value to "... clicked"
- In the `index.php` catch the `action` and call appropriate function from the Controller if `action` is not empty.

# Dependency Injection #