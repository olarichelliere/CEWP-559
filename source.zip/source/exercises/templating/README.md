# Templating #

Templating is the separation of visual elements like HTML/CSS/JavaScript from the code the crunches data and prepares it.

## Exercise ## 

Continue with the example in `Routing` and copy the templates folder to the root of that exercise.
Load the template file in the `View` and set the `title` and `description` variables on each View accordingly.